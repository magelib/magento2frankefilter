LICENSE: https://www.mageplaza.com/LICENSE.txt

FREE EXTENSION ON GITHUB

## Distribution & Rental

You may fork this repos (project), modify and publish it under Mageplaza brand, license.

Any special request, feel free to contact us at support@mageplaza.com
